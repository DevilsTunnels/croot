from devils import *
from telethon import Button, events
import subprocess, asyncio
@bot.on(events.CallbackQuery(data=b'rebotx'))
async def rebot_x(event):
  async def rebot_x_(event):
    await event.edit("`Processing Reboot Server`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up`")
    msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇⟨ Success Reboot Server ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Dalam Waktu 5 Detik**
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
    await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","setting")]])
    await asyncio.sleep(5)
    cmd = f'reboot'
    a = subprocess.check_output(cmd, shell=True).decode("utf-8")
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await rebot_x_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)
    
@bot.on(events.CallbackQuery(data=b'runingx'))
async def runing_x(event):
  async def runing_x_(event):
    await event.edit("`Processing Get Service In Server`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up`")
    cmd = f'/etc/shell/set runx'
    try:
      x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
      print(x)
    except:
      await event.respond("**Service Not Found**")
    else:
      z = subprocess.check_output(cmd, shell=True).decode("utf-8") 
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇⟨ Service Information ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
{z}
** » 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","setting")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await runing_x_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'resetx'))
async def reset_x(event):
  async def reset_x_(event):
    await event.edit("`Processing Get Service In Server`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up`")
    cmd = f'/etc/shell/set reset'
    try:
      x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
      print(x)
    except:
      await event.respond("**Service Not Found**")
    else:
      z = subprocess.check_output(cmd, shell=True).decode("utf-8") 
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇⟨ Restart Service ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
{z}
** » 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","setting")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await reset_x_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'backupx'))
async def backup_x(event):
  async def backup_x_(event):
    await event.edit("`Processing Backup Data Server`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up`")
    cmd = f'/etc/shell/set backup'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**Data Not Found**")
    else:
      z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
      ip = requests.get(f"https://ipv4.icanhazip.com").text.strip()
      b = [x.group() for x in re.finditer("link@(.*)",a)]
      print(b)
      link = re.search("link@(.*?)@", b[0]).group(1)
      msg = f"""
**━━━━━━━━━━━━━━━━━━━━━**
** ◇ Success Backup Data Server ◇**
**━━━━━━━━━━━━━━━━━━━━━**
Thank You For Using this Script
** » Domain :** `{DOMAIN}`
** » IP VPS :** `{ip}`
** » Link Google :** **{link}**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
** » Please Save Link Backup**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","backer")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await backup_x_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)


@bot.on(events.CallbackQuery(data=b'restorex'))
async def restore_x(event):
  async def restore_x_(event):
    async with bot.conversation(chat) as link:
      await event.respond('**Link Backup :**')
      link = link.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      link = (await link).raw_text
    await event.edit("`Processing Restore Data Server`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up`")
    cmd = f'printf "%s\n" "{link}" | /etc/shell/set restore'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
      ip = requests.get(f"https://ipv4.icanhazip.com").text.strip()
      msg = f"""
**━━━━━━━━━━━━━━━━━━━━━**
**  ◇ Success Restore Data Server ◇**
**━━━━━━━━━━━━━━━━━━━━━**
Thank You For Using this Script
** » Domain :** `{DOMAIN}`
** » IP VPS :** `{ip}`
** » Link Google :** **{link}**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
** » Please Restart Service**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","backer")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await restore_x_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
  async def backers_(event):
    inline = [
[Button.inline(" BACKUP","backupx"),
Button.inline(" RESTORE","restorex")],
[Button.inline("‹ Main Menu ›","setting")]]
    z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**      ◇⟨ BACKUP& RESTORE ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Domain   :** `{DOMAIN}`
**» ISP VPS  :** `{z["isp"]}`
**» Country  :** `{z["country"]}`
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await backers_(event)
  else:
    await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
  async def settings_(event):
    inline = [
[Button.inline(" Backup & Restore ","backer"),
Button.inline(" Running Service ","runingx")],
[Button.inline(" Restart Service ","resetx"),
Button.inline(" Reboot Server ","rebootx")],
[Button.inline(" ‹ Main Menu › ","menu")]]
    z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**     ☘️ OTHER SETTINGS ☘️  **
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Domain   :** `{DOMAIN}`
**» ISP VPS  :** `{z["isp"]}`
**» Country  :** `{z["country"]}`
**» 🤖@rizyulvpn**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await settings_(event)
  else:
    await event.answer("Access Denied",alert=True)
