from devils import *
import subprocess, asyncio
from telethon import Button, events
#CRATE SSH
@bot.on(events.CallbackQuery(data=b'create-vpn'))
async def create_vpn(event):
  async def create_vpn_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Password :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Crate Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{ip}" | /etc/shell/1'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("vpn://(.*)",a)]
      print(b)
      ns = re.search("vpn://(.*?):", b[0]).group(1)
      pub = re.search("vpn://(.*?):", b[1]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**     ◇ SSH OpenVPN Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Username     :** `{user}`
**» Password     :** `{pw}`
**» Limit Adress        :** `{ip} IP`
**» Host Domain       :** `{DOMAIN}`
**» Host NSDomain  :** `{ns}`
**» Pub Key               :** `{pub}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Port UDP Custom    :** `54-65535` 
**» Port SSL TLS/SNI    :** `443` 
**» Port WSS NTLS        :** `80, 8080, 8880`
**» Port WSS TLS/SNI   :** `443`
**» Port OVPN                :** `443, 1194, 2200`
**» Proxy Squid              :** `3128`
**» BadVPN UDP            :** `7100-7300`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» OpenVPN Config  :**
**https://{DOMAIN}:81/OpenVPN.zip**
**» Link Account       :**
**https://{DOMAIN}:81/ssh-{user}.txt**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `{later}`
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","vpn")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_vpn_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

# TRIAL SSH
@bot.on(events.CallbackQuery(data=b'trial-vpn'))
async def trial_vpn(event):
  async def trial_vpn_(event):
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    await event.edit("`Processing Crate Triall Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "${ip}" | /etc/shell/6'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      b = [x.group() for x in re.finditer("vpn://(.*)",a)]
      print(b)
      ns = re.search("vpn://(.*?):", b[0]).group(1)
      pub = re.search("vpn://(.*?):", b[1]).group(1)
      pw = re.search("vpn://(.*?):", b[2]).group(1)
      remark = re.search("vpn://(.*?):", b[3]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**     ◇ SSH OpenVPN Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Username     :** `{remark}`
**» Password     :** `{pw}`
**» Limit Adress        :** `{ip} IP`
**» Host Domain       :** `{DOMAIN}`
**» Host NSDomain  :** `{ns}`
**» Pub Key               :** `{pub}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Port UDP Custom    :** `54-65535` 
**» Port SSL TLS/SNI    :** `443` 
**» Port WSS NTLS        :** `80, 8080, 8880`
**» Port WSS TLS/SNI   :** `443`
**» Port OVPN                :** `443, 1194, 2200`
**» Proxy Squid              :** `3128`
**» BadVPN UDP            :** `7100-7300`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» OpenVPN Config  :**
**https://{DOMAIN}:81/OpenVPN.zip**
**» Link Account       :**
**https://{DOMAIN}:81/ssh-{remark}.txt**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `1 Day`
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","vpn")]])
##      cmd2 = f'/usr/sbin/triall ssh {remark} | at now +15 minutes'
##      subprocess.run(cmd2, shell=True, executable="/bin/bash")
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await trial_vpn_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

#CEK SSH
@bot.on(events.CallbackQuery(data=b'cek-vpn'))
async def cek_vpn(event):
  async def cek_vpn_(event):
    cmd = '/etc/shell/cek ssh'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**   ◇ List SSH OpenVPN Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
{z}
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹ Main Menu ›","vpn")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_vpn_(event)
  else:
    await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login-vpn'))
async def login_vpn(event):
  async def login_vpn_(event):
    cmd = '/etc/shell/loginx ssh'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""

{z}
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹ Main Menu ›","vpn")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await login_vpn_(event)
  else:
    await event.answer("Access Denied",alert=True) 

@bot.on(events.CallbackQuery(data=b'delete-vpn'))
async def delete_vpn(event):
  async def delete_vpn_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    await event.edit("`Processing Deleted Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" | /etc/shell/del ssh'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇ Succes Delete SSH Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","vpn")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_vpn_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vpn'))
async def ren_vpn(event):
  async def ren_vpn_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Update Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" | /etc/shell/ren ssh'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      x = [x.group() for x in re.finditer("exp://(.*)",a)]
      print(x)
      exp1 = re.search("exp://(.*?)@",x[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇ Succes Renew SSH Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» IP :** `{ip}`
**» Expired On :** `{exp1}`
**» 🤖@rizyulvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","vpn")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_vpn_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)
    
@bot.on(events.CallbackQuery(data=b'vpn'))
async def vpn(event):
  async def vpn_(event):
    inline = [
[Button.inline(" Create SSH ","create-vpn"),
Button.inline(" Triall SSH ","trial-vpn")],
[Button.inline(" Delete SSH ","delete-vpn"),
Button.inline(" Renew SSH ","renew-vpn")],
[Button.inline(" Member SSH ","cek-vpn"),
Button.inline(" Login SSH ","login-vpn")],
[Button.inline("‹ Main Menu ›","menu")]]
    z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**    ☘️ SSH OpenVPN MANAGER ☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Service   :** `SSH, UDP`
**» Service   :** `OpenVPN`
**» Service   :** `SlowDNS`
**» Domain   :** `{DOMAIN}`
**» ISP VPS  :** `{z["isp"]}`
**» Country  :** `{z["country"]}`
**» 🤖@rizyulvpn**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await vpn_(event)
  else:
    await event.answer("Access Denied",alert=True)
